<!-- Placeholder for firebaseConfig.js -->
